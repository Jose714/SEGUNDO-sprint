const hbs = require('hbs');

hbs.registerHelper('listar', (listado) => {
let texto = `	<form action="/eliminar" method="post">
		<table class='table table-striped table-hover'> 
				<thead class='thead-dark'>
				<th>Nombre</th>
				<th>Correo</th>
				<th>Cedula</th>
				<th>Telefono</th>
				<th></th>
				</thead>
				<tbody>`;
	listado.forEach(estudiante =>{
		texto = texto + 
				`<tr>
				<td> ${estudiante.nombre} </td>
				<td> ${estudiante.correo} </td>
				<td> ${estudiante.cedula} </td>
				<td> ${estudiante.telefono} </td>
				
				<td><button class="btn btn-danger" name="nombre" value="${estudiante.nombre}">Eliminar</button></td>
				
				</tr> `;
	})
	texto = texto + '</tbody> </table></form>';	
	return texto;

});

hbs.registerHelper('ver', (listado) => {
	let texto = `	<form action="/eliminarC" method="post">
			<table class='table table-striped table-hover'> 
					<thead class='thead-dark'>
					<th>Nombre de curso</th>
					<th>id</th>
					<th>Duracion</th>
					<th>Valor</th>
					<th></th>
					</thead>
					<tbody>`;
		listado.forEach(director =>{
			texto = texto + 
					`<tr>
					<td> ${director.curso} </td>
					<td> ${director.id} </td>
					<td> ${director.duracion}</td>
					<td> ${director.valor} </td>
					<td><button class="btn btn-danger" name="curso" value="${director.curso}">Eliminar</button></td>
					
					</tr> `;
		})
		texto = texto + '</tbody> </table></form>';	
		return texto;
	
	});

	hbs.registerHelper('aspirante', (listado) => {
		let texto = `	<form action="/eliminar" method="post">
				<table class='table table-striped table-hover'> 
						<thead class='thead-dark'>
						<th>Nombre del aspirante</th>
						<th>curso inscrito</th>
						<th>Identificacion</th>
						<th></th>
						</thead>
						<tbody>`;
			listado.forEach(aspirante =>{
				texto = texto + 
						`<tr>
						<td> ${aspirante.nombre} </td>
						<td> ${aspirante.curso} </td>
						<td> ${aspirante.cedula}</td>
						
						<td><button class="btn btn-danger" name="nombre" value="${aspirante.nombre}">Eliminar</button></td>
						
						</tr> `;
			})
			texto = texto + '</tbody> </table></form>';	
			return texto;
		
		});

		//cursos disponibles
		hbs.registerHelper('verC', (listado) => {
			let texto = `	<form action="/regisAspirante" method="post">
			
			<label >Nombre</label>
			<input type="text"  class="form-control"  name="nombre"  placeholder="Nombre del aspirante" required><br>   
			<label >Telefono</label>
			<input type="text"  class="form-control"  name="telefono"   placeholder="Telefono" required><br>  
			 <label >Cedula</label>
			<input type="text"  class="form-control"  name="cedula"  placeholder="Numero de cedula" required><br> 
			<label>Cursos</label>`;
							
							listado.forEach(verC =>{
								texto = texto + 
										`<select type="spinner"  class="form-control" >
										<option> ${verC.curso}</option><br><br>
										<button class="btn btn-danger" name="curso" value="${verC.curso}">Registrar</button>
										`;
										
							})
				texto = texto + '</select></form>';	
				return texto;
			
			});
		
	
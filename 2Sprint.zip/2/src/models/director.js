const mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

const Schema = mongoose.Schema;
const directorSchema = new Schema({
	curso : {
		type : String,
		required : true	,
		trim : true
	},
	id:{

		type: Number,
		required:true,
		default:0,
		min:1,
		max:9999
	},
	duracion : {
		type: Number,
		default: 0,
		min: 0,
		max:120				
	},
	valor: {
		type: Number,
		default: 0	,
		min: 0,
		max: 999999					
	}
});

directorSchema.plugin(uniqueValidator);

const Director = mongoose.model('Director', directorSchema);
module.exports = Director